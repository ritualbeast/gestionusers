const Empresas = [
    {
        id : 1,
        nombre: 'GOIT',
    },
    {
        id : 2,
        nombre: 'CNEL',
    },
    {
        id : 3,
        nombre: 'VERIS',
    },
    {
        id : 4,
        nombre: 'NEU',
    },
    {
        id : 5,
        nombre: 'MEDIGREEN',
    }
];

export default Empresas;
