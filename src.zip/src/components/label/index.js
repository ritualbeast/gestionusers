export { default } from './Label';
