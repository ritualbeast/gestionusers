global.BODY = ''
global.ERROR = 1
global.ERROR_LABEL = ''
global.EXPIRE_DATE = 1
global.REDIRECT_URL = ''
global.DATE_SEPARATOR = '-'