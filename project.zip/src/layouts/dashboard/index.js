export { default } from './DashboardLayout';
